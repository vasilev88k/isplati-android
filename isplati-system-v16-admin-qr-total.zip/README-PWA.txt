v15: додадена PWA конфигурација за почетен екран.
- manifest.webmanifest
- service worker се регистрира веднаш
- start_url и scope се ./
- standalone режим


Version 16: added 192x192 and 512x512 PNG app icons and fixed narrow-screen period action overflow.
