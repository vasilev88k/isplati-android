# Електронски систем за потврда на исплати

Едноставен систем за 32 партнери:
- Администратор се најавува со Supabase Auth.
- Се додаваат партнери и исплати.
- Секој партнер има траен QR/линк.
- Партнерот гледа само свои непотврдени и потврдени исплати.
- Потврдата запишува точен датум/час и име на примачот.
- Историјата не се препишува.

## Технологии
- Frontend: чист HTML/CSS/JavaScript
- Backend/database/auth: Supabase
- Hosting: Cloudflare Pages

## Поставување

### 1. Направи Supabase проект
Отвори https://supabase.com и направи Free project.

### 2. Креирај база
Во Supabase: SQL Editor -> New query.
Копирај ја целата содржина од `supabase/schema.sql` и изврши ја.

**Ако основниот SQL веќе си го извршил:** не го пуштај повторно. Наместо тоа, изврши ја содржината од `supabase/patch_after_existing_schema.sql`.

### 3. Креирај администратор
Во Supabase: Authentication -> Users -> Add user.
Креирај email и password за себе.

Потоа во SQL Editor изврши:
UPDATE public.admins
SET active = true
WHERE email = 'ТВОЈОТ_EMAIL';

(Табелата admins има trigger што автоматски го внесува новиот Auth user.)

### 4. Подеси frontend
Во оваа верзија `public/config.js` е веќе пополнет со Project URL и Publishable key за проектот Isplati.
Ако некогаш го смениш проектот, замени ги двете вредности со новите јавни API податоци.

Во frontend никогаш не ставај Secret/service_role key.

### 5. Тестирај локално
Може да го отвориш проектот со локален static server, на пример:
python -m http.server 8080 --directory public

Потоа отвори http://localhost:8080

### 6. Бесплатно поставување на Cloudflare Pages
Cloudflare Pages -> Create application -> Pages -> Direct Upload.
Качи ја содржината на папката `public`.

Алтернативно, стави го проектот на GitHub и поврзи го со Cloudflare Pages.

### ВАЖНО ЗА БЕЗБЕДНОСТ
Во frontend никогаш не ставај Supabase service_role key.
Во `config.js` оди само URL + anon/public key.

### QR
Администраторскиот екран автоматски генерира QR за секој партнер.
QR содржи линк во форма:
https://ТВОЈАТА-СТРАНИЦА/?partner=TOKEN

Кога ќе ја добиеш вистинската Cloudflare адреса, QR кодовите можеш повторно да ги генерираш/испечатиш од админ екранот.

## Како се користи
1. Администратор -> Партнери -> избери партнер.
2. Додај нова исплата.
3. Партнерот го скенира својот постојан QR.
4. Го внесува името на лицето што ја примило сумата.
5. Притиска ПОТВРДИ ПРИЕМ.
6. Исплатата автоматски оди во ПРИМЕНИ ИСПЛАТИ со точен датум и час.

Нема нов QR за секоја месечна исплата.


v10: hardened Push subscription saving with explicit Supabase RPC error reporting and validation.


v10 fixed: corrected push RPC helper recursion and added visible error reporting.

## v14 additions
- Administrator QR at the bottom opens a public all-partners history/status page.
- The public overview shows confirmed and unconfirmed payments independently of whether a month is marked finished.
- The overview can be printed or shared by link.
- The admin period area shows `СУМА ЗА ИСПЛАТА`, the current selected month's still-unconfirmed total.
- `ЗАВРШИ ИСПЛАТИ` and compact black `ПЕЧАТИ ИСПЛАТИ` are side by side.

Before deploying v14, run `supabase/public_overview_patch.sql` in Supabase SQL Editor.

## v14 additions
- Administrator QR at the bottom opens a public all-partners history/status page.
- The public overview shows confirmed and unconfirmed payments independently of whether a month is marked finished.
- The overview can be printed or shared by link.
- The admin period area shows `СУМА ЗА ИСПЛАТА`, the current selected month's still-unconfirmed total.
- `ЗАВРШИ ИСПЛАТИ` and compact black `ПЕЧАТИ ИСПЛАТИ` are side by side.

Before deploying v14, run `supabase/public_overview_patch.sql` in Supabase SQL Editor.
