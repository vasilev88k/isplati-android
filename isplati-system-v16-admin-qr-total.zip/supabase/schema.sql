create extension if not exists pgcrypto;

create table if not exists public.partners (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  token text not null unique default encode(gen_random_bytes(18),'hex'),
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid not null references public.partners(id) on delete restrict,
  period text not null,
  amount numeric(12,2) not null check (amount > 0),
  created_at timestamptz not null default now(),
  confirmed_at timestamptz,
  recipient_name text
);

create table if not exists public.admins (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create or replace function public.on_auth_user_created()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.admins(id,email) values(new.id,new.email)
  on conflict (id) do update set email=excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.on_auth_user_created();

alter table public.partners enable row level security;
alter table public.payments enable row level security;
alter table public.admins enable row level security;

create policy "public partner by token"
on public.partners for select to anon, authenticated
using (true);

create policy "admins read partners"
on public.partners for select to authenticated
using (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

create policy "admins insert partners"
on public.partners for insert to authenticated
with check (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

create policy "admins update partners"
on public.partners for update to authenticated
using (exists(select 1 from public.admins a where a.id=auth.uid() and a.active))
with check (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

create policy "admins read payments"
on public.payments for select to authenticated
using (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

create policy "admins insert payments"
on public.payments for insert to authenticated
with check (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

create policy "admins read own admin row"
on public.admins for select to authenticated
using (id=auth.uid());

create or replace function public.confirm_payment(
  p_token text,
  p_payment_id uuid,
  p_recipient text
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  pid uuid;
begin
  select p.id into pid
  from public.payments p
  join public.partners pr on pr.id=p.partner_id
  where p.id=p_payment_id and pr.token=p_token and p.confirmed_at is null;

  if pid is null then
    raise exception 'Исплатата не постои или веќе е потврдена.';
  end if;

  update public.payments
  set confirmed_at=now(), recipient_name=left(trim(p_recipient),150)
  where id=pid and confirmed_at is null;

  return true;
end;
$$;

revoke all on function public.confirm_payment(text,uuid,text) from public;
grant execute on function public.confirm_payment(text,uuid,text) to anon, authenticated;

insert into public.partners(name) values
("Ване лимар - Владевци"),
("Вен Вочер Муртино 2"),
("Виоли Промет Василево"),
("Даво Откуп"),
("Даутови-Дабиле"),
("Дими Мебел"),
("Елмидо-Еднокуќево"),
("Жикол база"),
("Император"),
("Интерметал Апартмани"),
("Интерметал Апартмани 2"),
("Кини Моноспитово"),
("Мајстор Ново Село"),
("Мајстор Пепи"),
("Марбет Моноспитово"),
("МН Мониспитово"),
("Муртино Чифлик"),
("ОАЗА"),
("Оризо комерц"),
("Перо Пром Смолари"),
("Продавница Злеово"),
("Сервис Китка"),
("Сервис Марјан"),
("Стоко-пром"),
("Тако Пром -Дабиле"),
("Тома Радово - Босилово"),
("Тома Радово2 - радово"),
("Фис пром 2008 - Муртино"),
("Христмил-Промет"),
("Џив - Муртино"),
("Џови Компани"),
("Шкода-салон")
on conflict (name) do nothing;
