-- Дозволи му на активен администратор да менува/брише исплати и да брише партнер.
-- Партнер со постоечки исплати намерно не се брише; прво се бришат исплатите.

create policy "admins update payments"
on public.payments for update to authenticated
using (exists(select 1 from public.admins a where a.id=auth.uid() and a.active))
with check (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

create policy "admins delete payments"
on public.payments for delete to authenticated
using (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

create policy "admins delete partners"
on public.partners for delete to authenticated
using (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));
