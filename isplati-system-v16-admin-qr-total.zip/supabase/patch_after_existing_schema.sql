-- Овој patch се пушта ОТКАКО основниот schema.sql веќе е извршен.
-- Го прави партнерскиот QR пристап без јавно читање на целата partners/payments табела.

create or replace function public.get_partner_by_token(p_token text)
returns table (id uuid, name text, token text)
language sql
security definer
set search_path = public
as $$
  select p.id, p.name, p.token
  from public.partners p
  where p.token = p_token
  limit 1;
$$;

revoke all on function public.get_partner_by_token(text) from public;
grant execute on function public.get_partner_by_token(text) to anon, authenticated;

create or replace function public.get_partner_payments(p_token text)
returns table (id uuid, period text, amount numeric, created_at timestamptz, confirmed_at timestamptz, recipient_name text)
language sql
security definer
set search_path = public
as $$
  select p.id, p.period, p.amount, p.created_at, p.confirmed_at, p.recipient_name
  from public.payments p
  join public.partners pr on pr.id = p.partner_id
  where pr.token = p_token
  order by p.created_at desc;
$$;

revoke all on function public.get_partner_payments(text) from public;
grant execute on function public.get_partner_payments(text) to anon, authenticated;
