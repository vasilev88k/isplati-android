create or replace function public.confirm_all_payments(
  p_token text,
  p_recipient text
)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  changed_count integer;
begin
  if trim(coalesce(p_recipient, '')) = '' then
    raise exception 'Името на примателот не може да биде празно.';
  end if;

  update public.payments p
  set
    confirmed_at = now(),
    recipient_name = left(trim(p_recipient),150)
  from public.partners pr
  where p.partner_id = pr.id
    and pr.token = p_token
    and p.confirmed_at is null;

  get diagnostics changed_count = row_count;
  return changed_count;
end;
$$;

revoke all on function public.confirm_all_payments(text,text) from public;
grant execute on function public.confirm_all_payments(text,text) to anon, authenticated;
