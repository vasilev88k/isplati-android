-- Public overview used by the administrator QR code.
-- The QR URL itself is the access token.
create or replace function public.get_public_payment_overview(p_token text)
returns table (
  partner_name text,
  period text,
  amount numeric,
  confirmed_at timestamptz,
  recipient_name text
)
language sql
security definer
set search_path = public
as $$
  select pr.name, p.period, p.amount, p.confirmed_at, p.recipient_name
  from public.payments p
  join public.partners pr on pr.id = p.partner_id
  where p_token = 'ovw_8c7f2e5a4d1b9c63f0a2e7d5b8c4f1a9'
  order by p.created_at desc;
$$;
revoke all on function public.get_public_payment_overview(text) from public, anon, authenticated;
grant execute on function public.get_public_payment_overview(text) to anon, authenticated;
