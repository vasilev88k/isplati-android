package mk.isplati.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFFF7F8FA)
private val Ink = Color(0xFF101828)
private val Muted = Color(0xFF667085)
private val Green = Color(0xFF087443)
private val GreenSoft = Color(0xFFE9F7EF)
private val Card = Color.White

private data class Partner(val name: String, val amount: Int, val confirmed: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IsplatiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IsplatiApp() {
    var operator by remember { mutableStateOf("Кирил") }
    var month by remember { mutableStateOf("Октомври") }
    var tab by remember { mutableStateOf(0) }
    var operatorOpen by remember { mutableStateOf(false) }
    var monthOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val partners = remember(operator, month) {
        listOf(
            Partner("Ване лимар – Владејвци", 3500),
            Partner("Вен Вочер Муртино 2", 2000),
            Partner("Даво Откуп", 6950),
            Partner("Дими Мебел", 0),
            Partner("Елмидо – Еднокуќево", 0)
        )
    }
    val total = partners.sumOf { it.amount }

    Scaffold(
        containerColor = Bg,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("ИСПЛАТИ", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp) },
                navigationIcon = {
                    IconButton(onClick = { tab = 3 }) {
                        Icon(Icons.Default.Settings, contentDescription = "Поставки", tint = Ink)
                    }
                },
                actions = {
                    IconButton(onClick = { tab = 2 }) {
                        Icon(Icons.Default.QrCode2, contentDescription = "QR", tint = Ink)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Bg)
            )
        },
        bottomBar = {
            Surface(color = Card, shadowElevation = 8.dp, modifier = Modifier.navigationBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().height(72.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavItem(Icons.Default.Payments, "Исплати", tab == 0) { tab = 0 }
                    NavItem(Icons.Default.ReceiptLong, "Историја", tab == 1) { tab = 1 }
                    NavItem(Icons.Default.QrCode2, "QR", tab == 2) { tab = 2 }
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> Dashboard(
                pad, operator, month, total, partners,
                operatorOpen, monthOpen,
                onOperatorOpen = { operatorOpen = !operatorOpen },
                onMonthOpen = { monthOpen = !monthOpen },
                onOperator = { operator = it; operatorOpen = false },
                onMonth = { month = it; monthOpen = false },
                onAdd = { openWeb(context, "https://little-fire-d41d.vasilev88k.workers.dev/") },
                onOpen = { openWeb(context, "https://little-fire-d41d.vasilev88k.workers.dev/") }
            )
            1 -> HistoryScreen(pad)
            2 -> QrScreen(pad)
            3 -> SettingsScreen(pad)
        }
    }
}

@Composable
private fun Dashboard(
    pad: androidx.compose.foundation.layout.PaddingValues,
    operator: String, month: String, total: Int, partners: List<Partner>,
    operatorOpen: Boolean, monthOpen: Boolean,
    onOperatorOpen: () -> Unit, onMonthOpen: () -> Unit,
    onOperator: (String) -> Unit, onMonth: (String) -> Unit,
    onAdd: () -> Unit, onOpen: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Selector("ОПЕРАТОР", operator, Modifier.weight(1f), operatorOpen, onOperatorOpen) {
                    listOf("Кирил", "Марјан").forEach { value ->
                        DropdownMenuItem(text = { Text(value) }, onClick = { onOperator(value) })
                    }
                }
                Selector("МЕСЕЦ", month, Modifier.weight(1f), monthOpen, onMonthOpen) {
                    listOf("Октомври", "Ноември", "Декември").forEach { value ->
                        DropdownMenuItem(text = { Text(value) }, onClick = { onMonth(value) })
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Ink),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("ВКУПНО ЗА ИСПЛАТА", color = Color(0xFFB7C0CD), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("${format(total)} ден.", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).background(Green, RoundedCornerShape(50)))
                        Spacer(Modifier.width(7.dp))
                        Text("$operator · $month", color = Color(0xFFD5DAE2), fontSize = 13.sp)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ПАРТНЕРИ", color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                Text("${partners.size}", color = Muted, fontSize = 13.sp)
            }
        }
        items(partners) { partner ->
            PartnerCard(partner, onAdd, onOpen)
        }
    }
}

@Composable
private fun Selector(label: String, value: String, modifier: Modifier, expanded: Boolean, onClick: () -> Unit, menu: @Composable () -> Unit) {
    Box(modifier) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Card),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
        ) {
            Column(Modifier.padding(horizontal = 15.dp, vertical = 11.dp)) {
                Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Muted, letterSpacing = .8.sp)
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(value, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp))
                }
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = onClick) { menu() }
    }
}

@Composable
private fun PartnerCard(partner: Partner, onAdd: () -> Unit, onOpen: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(if (partner.amount > 0) GreenSoft else Color(0xFFF0F2F5), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    if (partner.amount > 0) Icon(Icons.Default.Payments, null, tint = Green, modifier = Modifier.size(21.dp))
                    else Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF98A2B3), modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(partner.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(if (partner.amount > 0) "Подготвено за исплата" else "Нема внесена исплата", color = Muted, fontSize = 12.sp)
                }
                if (partner.amount > 0) {
                    Text("${format(partner.amount)} ден.", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = Ink)
                }
            }
            Spacer(Modifier.height(13.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onOpen, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 11.dp)) {
                    Text("ОТВОРИ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.width(5.dp)); Icon(Icons.Default.ArrowForwardIos, null, modifier = Modifier.size(13.dp))
                }
                Button(onClick = onAdd, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Ink), modifier = Modifier.size(50.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "Додај")
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(pad: androidx.compose.foundation.layout.PaddingValues) {
    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text("Историја", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Spacer(Modifier.height(5.dp)); Text("Потврдени исплати", color = Muted)
        Spacer(Modifier.height(20.dp))
        EmptyCard("Историјата ќе се поврзе со постоечката Supabase база во следниот чекор.")
    }
}

@Composable
private fun QrScreen(pad: androidx.compose.foundation.layout.PaddingValues) {
    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text("QR пристап", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Spacer(Modifier.height(5.dp)); Text("Партнери и оператори", color = Muted)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.QrCode2, null, tint = Ink, modifier = Modifier.size(150.dp))
                Spacer(Modifier.height(14.dp)); Text("QR кодовите ќе останат исти.", fontWeight = FontWeight.Bold, color = Ink)
                Text("Нема потреба од нов QR за секоја исплата.", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SettingsScreen(pad: androidx.compose.foundation.layout.PaddingValues) {
    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text("Поставки", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Spacer(Modifier.height(20.dp))
        EmptyCard("Административните поставки и управувањето со партнерите ќе останат поврзани со постоечкиот систем.")
    }
}

@Composable
private fun EmptyCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(22.dp)) {
        Text(text, Modifier.padding(20.dp), color = Muted, lineHeight = 20.sp)
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 6.dp)) {
        Icon(icon, null, tint = if (selected) Green else Muted, modifier = Modifier.size(23.dp))
        Spacer(Modifier.height(3.dp)); Text(label, fontSize = 11.sp, color = if (selected) Green else Muted, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

private fun openWeb(context: android.content.Context, url: String) {
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

private fun format(n: Int): String = java.text.NumberFormat.getIntegerInstance(java.util.Locale("mk", "MK")).format(n)
