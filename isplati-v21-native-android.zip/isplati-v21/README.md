# Исплати v21

Native Android UI built with Jetpack Compose. The current backend/web system remains intact.

GitHub Actions: `android/.github/workflows/build-apk.yml`

Version: 2.1 / versionCode 21
