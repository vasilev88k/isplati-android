-- v19: оператори Кирил / Марјан
create table if not exists public.operators (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  token text not null unique default encode(gen_random_bytes(18),'hex'),
  created_at timestamptz not null default now()
);

insert into public.operators(name) values ('Кирил'), ('Марјан')
on conflict (name) do nothing;

alter table public.partners add column if not exists operator_id uuid;

update public.partners p
set operator_id = o.id
from public.operators o
where o.name = 'Кирил' and p.operator_id is null;

alter table public.partners
  drop constraint if exists partners_operator_id_fkey;
alter table public.partners
  add constraint partners_operator_id_fkey
  foreign key (operator_id) references public.operators(id) on delete restrict;

alter table public.partners alter column operator_id set not null;

alter table public.operators enable row level security;
drop policy if exists "admins read operators" on public.operators;
create policy "admins read operators"
on public.operators for select to authenticated
using (exists(select 1 from public.admins a where a.id=auth.uid() and a.active));

-- Public QR: one operator at a time.
create or replace function public.get_public_operator_overview(p_token text)
returns table (
  operator_name text,
  partner_name text,
  period text,
  amount numeric,
  confirmed_at timestamptz,
  recipient_name text
)
language sql
security definer
set search_path = public
as $$
  select o.name, pr.name, p.period, p.amount, p.confirmed_at, p.recipient_name
  from public.operators o
  join public.partners pr on pr.operator_id=o.id
  join public.payments p on p.partner_id=pr.id
  where o.token=p_token
  order by p.created_at desc;
$$;
revoke all on function public.get_public_operator_overview(text) from public, anon, authenticated;
grant execute on function public.get_public_operator_overview(text) to anon, authenticated;

-- Public QR: all operators together.
create or replace function public.get_public_all_operators_overview(p_token text)
returns table (
  operator_name text,
  partner_name text,
  period text,
  amount numeric,
  confirmed_at timestamptz,
  recipient_name text
)
language sql
security definer
set search_path = public
as $$
  select o.name, pr.name, p.period, p.amount, p.confirmed_at, p.recipient_name
  from public.operators o
  join public.partners pr on pr.operator_id=o.id
  join public.payments p on p.partner_id=pr.id
  where p_token = 'all_operators_7f9d2c4a6b1e8f30'
  order by o.name, p.created_at desc;
$$;
revoke all on function public.get_public_all_operators_overview(text) from public, anon, authenticated;
grant execute on function public.get_public_all_operators_overview(text) to anon, authenticated;

-- Public all-operator QR token is intentionally fixed so the QR can remain permanent.
