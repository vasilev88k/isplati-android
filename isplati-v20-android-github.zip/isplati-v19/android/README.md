# Исплати v20 Android

Ова е поправениот Android проект за тест APK.

- Ја отвора веб апликацијата во сопствен Android прозорец, не во Chrome Custom Tab.
- Android Back се враќа низ историјата на веб апликацијата.
- URL: https://little-fire-d41d.vasilev88k.workers.dev/
- Package: mk.isplati.app
- Version: 1.20

## Градење преку телефон
1. Креирај GitHub repository.
2. Upload-ирај ја целата содржина на оваа папка.
3. Отвори Actions → Build Исплати APK → Run workflow.
4. По завршување отвори го workflow run-от → Artifacts → isplati-v20-debug-apk.
5. Преземи го ZIP-от и извлечи го `app-debug.apk`.
6. Инсталирај го APK на Android телефон.

Забелешка: оваа тест верзија е Android WebView wrapper. Web Push од веб-верзијата може да бара дополнителна native/TWA интеграција; не го третираме како завршен production push build додека не го тестираме.
