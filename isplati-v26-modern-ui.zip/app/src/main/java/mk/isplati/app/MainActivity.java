package mk.isplati.app;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;

public class MainActivity extends AppCompatActivity {
    static final String URL="https://ykuciusyytovkzrazbpv.supabase.co";
    static final String KEY="sb_publishable_8c4MxEH4JdqGvxJyiniUeg_eFutQEvo";
    static final String WORKER="https://little-fire-d41d.vasilev88k.workers.dev/";

    int BG=Color.rgb(4,22,29), PANEL=Color.rgb(11,34,44), PANEL2=Color.rgb(14,43,55), GREEN=Color.rgb(41,221,143), WHITE=Color.WHITE, MUTED=Color.rgb(170,188,194), LINE=Color.rgb(39,69,79), ORANGE=Color.rgb(255,173,74);
    LinearLayout root,content;
    ScrollView mainScroll;
    TextView total,paid,remaining;
    String access="";
    ArrayList<JSONObject> partners=new ArrayList<>();
    HashSet<String> selected=new HashSet<>();
    String operator="Кирил";
    int monthIndex=8,year=2026;
    int restoreScrollY=0;
    String[] months={"Јануари","Февруари","Март","Април","Мај","Јуни","Јули","Август","Септември","Октомври","Ноември","Декември"};

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(int c,int sc,float r){GradientDrawable g=bg(c,r);g.setStroke(dp(1),sc);return g;}

    @Override public void onCreate(Bundle b){
        super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        access=getPreferences(0).getString("access",""); if(access.isEmpty()) login(); else home();
    }

    @Override public void onBackPressed(){
        if(mainScroll!=null && mainScroll.getVisibility()==View.VISIBLE){
            restoreScrollY=mainScroll.getScrollY();
            home();
        } else super.onBackPressed();
    }

    void base(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);}
    Button btn(String s,boolean filled){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTypeface(null,1);b.setTextColor(filled?Color.rgb(0,35,25):WHITE);b.setBackground(bg(filled?GREEN:PANEL2,14));b.setPadding(dp(8),0,dp(8),0);b.setMinHeight(dp(42));return b;}
    TextView fieldLabel(String s){TextView t=tv(s.toUpperCase(),9,MUTED);t.setTypeface(null,1);t.setLetterSpacing(.04f);return t;}
    EditText amountField(){EditText e=new EditText(this);e.setSingleLine();e.setTextColor(WHITE);e.setHintTextColor(Color.rgb(133,157,166));e.setTextSize(14);e.setHint("Износ");e.setInputType(2);e.setBackground(stroke(PANEL2,LINE,12));e.setPadding(dp(12),0,dp(12),0);return e;}

    void top(String title,boolean back){
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),dp(7),dp(14),dp(3));
        if(back){Button b=btn("‹",false);b.setTextSize(30);bar.addView(b,new LinearLayout.LayoutParams(dp(48),dp(48)));b.setOnClickListener(v->home());}
        TextView t=tv(title,18,WHITE);t.setTypeface(null,1);bar.addView(t,new LinearLayout.LayoutParams(0,dp(52),1));root.addView(bar);
    }

    void login(){
        base(); Space sp=new Space(this);root.addView(sp,new LinearLayout.LayoutParams(1,dp(70)));
        TextView l=tv("ИСПЛАТИ",34,WHITE);l.setTypeface(null,1);l.setGravity(Gravity.CENTER);root.addView(l);
        TextView sub=tv("Управување со исплатите",14,MUTED);sub.setGravity(Gravity.CENTER);root.addView(sub);
        CardView c=new CardView(this);c.setCardBackgroundColor(PANEL);c.setRadius(dp(20));
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(22),dp(22),dp(22));
        TextView h=tv("Најава",22,WHITE);h.setTypeface(null,1);box.addView(h);
        EditText e=amountField();e.setHint("Е-пошта");e.setInputType(33);box.addView(e,new LinearLayout.LayoutParams(-1,dp(52)));
        EditText p=amountField();p.setHint("Лозинка");p.setInputType(129);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(52));pp.topMargin=dp(10);box.addView(p,pp);
        Button go=btn("Најави се",true);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(50));gp.topMargin=dp(16);box.addView(go,gp);c.addView(box);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(dp(18),dp(28),dp(18),0);root.addView(c,cp);
        go.setOnClickListener(v->new Thread(()->{try{JSONObject j=new JSONObject();j.put("email",e.getText().toString());j.put("password",p.getText().toString());JSONObject r=req("/auth/v1/token?grant_type=password","POST",j.toString(),null);access=r.getString("access_token");getPreferences(0).edit().putString("access",access).apply();runOnUiThread(this::home);}catch(Exception x){runOnUiThread(()->Toast.makeText(this,"Неуспешна најава",Toast.LENGTH_LONG).show());}}).start());
    }

    JSONObject req(String path,String method,String body,String token)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(URL+path).openConnection();c.setRequestMethod(method);c.setRequestProperty("apikey",KEY);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");if(token!=null&&!token.isEmpty())c.setRequestProperty("Authorization","Bearer "+token);
        if(body!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String s=read(in);if(code<200||code>=300)throw new Exception(s);return s.isEmpty()?new JSONObject():new JSONObject(s);
    }
    JSONArray get(String path)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(URL+path).openConnection();c.setRequestProperty("apikey",KEY);c.setRequestProperty("Authorization","Bearer "+access);int code=c.getResponseCode();String s=read(code<300?c.getInputStream():c.getErrorStream());if(code>=300)throw new Exception(s);return new JSONArray(s);
    }
    String read(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[4096];int n;while((n=in.read(z))>0)b.write(z,0,n);return new String(b.toByteArray(),StandardCharsets.UTF_8);}
    String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}

    void home(){
        base();topbar();filters();
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),0,dp(14),dp(20));
        mainScroll=new ScrollView(this);mainScroll.setClipToPadding(false);mainScroll.addView(content);root.addView(mainScroll,new LinearLayout.LayoutParams(-1,0,1));
        new Thread(this::loadPartners).start();
    }

    void topbar(){
        LinearLayout b=new LinearLayout(this);b.setGravity(Gravity.CENTER);b.setPadding(dp(14),dp(8),dp(14),0);Button op=btn("●  "+operator+" ⌄",false);b.addView(op,new LinearLayout.LayoutParams(-1,dp(50)));op.setOnClickListener(v->operatorPicker());root.addView(b);
    }

    void filters(){
        LinearLayout f=new LinearLayout(this);f.setPadding(dp(14),dp(8),dp(14),dp(8));
        LinearLayout m=drop("МЕСЕЦ\n"+months[monthIndex]);LinearLayout y=drop("ГОДИНА\n"+year);LinearLayout o=drop("ОПЕРАТОР\n"+operator);
        f.addView(m,new LinearLayout.LayoutParams(0,dp(62),1));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(62),1);q.leftMargin=dp(6);f.addView(y,q);q=new LinearLayout.LayoutParams(0,dp(62),1);q.leftMargin=dp(6);f.addView(o,q);root.addView(f);
        m.setOnClickListener(v->monthPicker());y.setOnClickListener(v->yearPicker());o.setOnClickListener(v->operatorPicker());
    }
    LinearLayout drop(String s){LinearLayout d=new LinearLayout(this);d.setOrientation(LinearLayout.VERTICAL);d.setPadding(dp(10),dp(6),dp(8),dp(4));d.setBackground(stroke(PANEL,LINE,12));int n=s.indexOf('\n');TextView a=fieldLabel(s.substring(0,n));TextView b=tv(s.substring(n+1),12,WHITE);d.addView(a);d.addView(b);return d;}

    void hero(){
        TextView logo=tv("ИСПЛАТИ",34,WHITE);logo.setTypeface(null,1);logo.setGravity(Gravity.CENTER);content.addView(logo,new LinearLayout.LayoutParams(-1,dp(64)));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(16),dp(18),dp(14));card.setBackground(bg(PANEL,18));
        TextView a=tv("▣   Вкупно за исплата",13,WHITE);a.setTypeface(null,1);card.addView(a);total=tv("0 ден",27,WHITE);total.setTypeface(null,1);card.addView(total);
        LinearLayout st=new LinearLayout(this);st.setPadding(0,dp(10),0,0);paid=tv("✓  Исплатени\n0 ден",12,GREEN);remaining=tv("◷  За исплата\n0 ден",12,ORANGE);st.addView(paid,new LinearLayout.LayoutParams(0,dp(52),1));st.addView(remaining,new LinearLayout.LayoutParams(0,dp(52),1));card.addView(st);content.addView(card,new LinearLayout.LayoutParams(-1,dp(142)));
    }

    void actions(){
        LinearLayout a=new LinearLayout(this);a.setPadding(0,dp(10),0,dp(7));Button print=btn("▣  ПЕЧАТИ ИСПЛАТИ",true);Button partnersBtn=btn("♟  Партнери",false);
        a.addView(print,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),.72f);p.leftMargin=dp(8);a.addView(partnersBtn,p);content.addView(a);
        LinearLayout qr=new LinearLayout(this);qr.setGravity(Gravity.CENTER_VERTICAL);qr.setPadding(dp(14),0,dp(12),0);qr.setBackground(stroke(PANEL,LINE,15));TextView qt=tv("▦  QR за "+operator,14,WHITE);qt.setTypeface(null,1);qr.addView(qt,new LinearLayout.LayoutParams(0,dp(56),1));qr.addView(tv("›",30,MUTED));content.addView(qr,new LinearLayout.LayoutParams(-1,dp(58)));qr.setOnClickListener(v->showOperatorQr(operator));
        print.setOnClickListener(v->Toast.makeText(this,"Избирај ги партнерите, па притисни „Заврши исплати“. За печатење користи веб-верзија.",Toast.LENGTH_LONG).show());
        partnersBtn.setOnClickListener(v->{if(mainScroll!=null)mainScroll.smoothScrollTo(0,Math.max(0,mainScroll.getChildAt(0).getHeight()-dp(500)));});
    }

    void partnersList(){
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView h=tv("ПАРТНЕРИ",11,MUTED);h.setTypeface(null,1);head.addView(h,new LinearLayout.LayoutParams(0,dp(36),1));Button finish=btn("Заврши исплати",true);head.addView(finish,new LinearLayout.LayoutParams(dp(132),dp(40)));content.addView(head);
        finish.setOnClickListener(v->finishSelected());
        for(JSONObject p:partners)partnerCard(p);
    }

    void partnerCard(JSONObject p){
        CardView c=new CardView(this);c.setCardBackgroundColor(PANEL);c.setRadius(dp(16));c.setCardElevation(0);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(10),dp(11),dp(10));
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox cb=new CheckBox(this);cb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{GREEN,Color.rgb(120,145,153)}));cb.setChecked(selected.contains(p.optString("id")));row.addView(cb,new LinearLayout.LayoutParams(dp(42),dp(48)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);TextView n=tv(p.optString("name"),14,WHITE);n.setTypeface(null,1);names.addView(n);TextView per=tv(months[monthIndex]+" "+year,10,MUTED);names.addView(per);row.addView(names,new LinearLayout.LayoutParams(0,dp(56),1));
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView qrSmall=tv("▦ QR",10,GREEN);qrSmall.setGravity(Gravity.CENTER);right.addView(qrSmall,new LinearLayout.LayoutParams(dp(62),dp(24)));
        TextView amount=tv(partnerAmountText(p),11,MUTED);amount.setGravity(Gravity.CENTER);right.addView(amount,new LinearLayout.LayoutParams(dp(72),dp(24)));
        row.addView(right,new LinearLayout.LayoutParams(dp(78),dp(52)));box.addView(row);
        LinearLayout ctl=new LinearLayout(this);ctl.setGravity(Gravity.CENTER_VERTICAL);EditText amt=amountField();ctl.addView(amt,new LinearLayout.LayoutParams(0,dp(43),1));Button add=btn("+ Додај",true);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(96),dp(43));ap.leftMargin=dp(7);ctl.addView(add,ap);box.addView(ctl);c.addView(box);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(120));cp.bottomMargin=dp(7);content.addView(c,cp);
        View.OnClickListener open=v->partnerHistory(p);
        c.setOnClickListener(open);row.setOnClickListener(open);names.setOnClickListener(open);n.setOnClickListener(open);per.setOnClickListener(open);right.setOnClickListener(v->showPartnerQr(p));qrSmall.setOnClickListener(v->showPartnerQr(p));
        cb.setOnClickListener(v->{if(cb.isChecked())selected.add(p.optString("id"));else selected.remove(p.optString("id"));});
        add.setOnClickListener(v->addPayment(p,amt));
    }

    String partnerAmountText(JSONObject p){return "QR + исплати";}

    void loadPartners(){
        try{JSONArray a=get("/rest/v1/partners?select=*&order=name.asc");partners.clear();for(int i=0;i<a.length();i++)partners.add(a.getJSONObject(i));runOnUiThread(()->{content.removeAllViews();hero();actions();partnersList();loadTotals();if(restoreScrollY>0){final int y=restoreScrollY;mainScroll.postDelayed(()->mainScroll.scrollTo(0,y),120);restoreScrollY=0;}});}
        catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Не може да се вчитаат партнерите",Toast.LENGTH_LONG).show());}
    }

    void loadTotals(){new Thread(()->{try{String per=months[monthIndex]+" "+year;JSONArray a=get("/rest/v1/payments?select=partner_id,amount,confirmed_at&period=eq."+enc(per));double t=0,r=0;for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);double z=x.optDouble("amount");t+=z;if(x.isNull("confirmed_at"))r+=z;}double pt=t-r;final double ft=t,fpt=pt,fr=r;runOnUiThread(()->{total.setText(String.format(Locale.US,"%,.0f ден",ft));paid.setText(String.format(Locale.US,"✓  Исплатени\n%,.0f ден",fpt));remaining.setText(String.format(Locale.US,"◷  За исплата\n%,.0f ден",fr));});}catch(Exception ignored){}}).start();}

    void addPayment(JSONObject p,EditText a){new Thread(()->{try{double x=Double.parseDouble(a.getText().toString());if(x<=0)throw new Exception("Внеси износ.");JSONObject j=new JSONObject();j.put("partner_id",p.getString("id"));j.put("period",months[monthIndex]+" "+year);j.put("amount",x);req("/rest/v1/payments","POST",j.toString(),access);runOnUiThread(()->{a.setText("");Toast.makeText(this,"Исплатата е додадена ✓",Toast.LENGTH_SHORT).show();loadPartners();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}

    void finishSelected(){
        if(selected.isEmpty()){Toast.makeText(this,"Избери барем еден партнер.",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("Заврши исплати").setMessage("Да се завршат исплатите за избраните партнери за "+months[monthIndex]+" "+year+"?").setNegativeButton("Откажи",null).setPositiveButton("Заврши",(d,w)->Toast.makeText(this,"Исплатите се означени за завршување.",Toast.LENGTH_SHORT).show()).show();
    }

    void partnerHistory(JSONObject p){
        final int oldScroll=mainScroll==null?0:mainScroll.getScrollY();
        new Thread(()->{try{JSONArray a=get("/rest/v1/payments?select=*&partner_id=eq."+enc(p.getString("id"))+"&order=created_at.desc");runOnUiThread(()->partnerDetail(p,a,oldScroll));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Не може да се вчита партнерот",Toast.LENGTH_LONG).show());}}).start();
    }

    void partnerDetail(JSONObject p,JSONArray a,int oldScroll){
        base();top(p.optString("name"),true);
        ScrollView sv=new ScrollView(this);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(8),dp(14),dp(24));sv.addView(l);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        TextView title=tv("Партнер",10,MUTED);title.setTypeface(null,1);l.addView(title);TextView name=tv(p.optString("name"),22,WHITE);name.setTypeface(null,1);l.addView(name,new LinearLayout.LayoutParams(-1,dp(46)));
        LinearLayout buttons=new LinearLayout(this);Button share=btn("Сподели",true);Button finish=btn("Заврши исплати",false);buttons.addView(share,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,dp(46),1);fp.leftMargin=dp(8);buttons.addView(finish,fp);l.addView(buttons);
        share.setOnClickListener(v->sharePartner(p));finish.setOnClickListener(v->finishPartner(p));
        LinearLayout qrCard=new LinearLayout(this);qrCard.setOrientation(LinearLayout.VERTICAL);qrCard.setGravity(Gravity.CENTER);qrCard.setPadding(dp(12),dp(12),dp(12),dp(12));qrCard.setBackground(stroke(PANEL,LINE,18));TextView qh=tv("QR код на партнерот",15,WHITE);qh.setGravity(Gravity.CENTER);qh.setTypeface(null,1);qrCard.addView(qh,new LinearLayout.LayoutParams(-1,dp(40)));ImageView image=new ImageView(this);Bitmap bm=makeQr(partnerUrl(p),dp(220));image.setImageBitmap(bm);qrCard.addView(image,new LinearLayout.LayoutParams(-1,dp(245)));l.addView(qrCard,new LinearLayout.LayoutParams(-1,dp(295)));
        TextView hist=tv("Историја на исплати",16,WHITE);hist.setTypeface(null,1);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(44));hp.topMargin=dp(14);l.addView(hist,hp);
        for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(12),dp(6),dp(12),dp(6));r.setBackground(bg(PANEL,13));TextView t=tv(x.optString("period")+"\n"+String.format(Locale.US,"%,.0f ден",x.optDouble("amount")),12,WHITE);t.setTypeface(null,1);r.addView(t,new LinearLayout.LayoutParams(0,dp(68),1));r.addView(tv(x.isNull("confirmed_at")?"За исплата":"Исплатено",11,x.isNull("confirmed_at")?ORANGE:GREEN));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(76));rp.bottomMargin=dp(7);l.addView(r,rp);}
    }

    String partnerUrl(JSONObject p){return WORKER+"?admin_partner="+p.optString("id","");}
    Bitmap makeQr(String u,int size){try{BitMatrix m=new MultiFormatWriter().encode(u,BarcodeFormat.QR_CODE,size,size);Bitmap b=Bitmap.createBitmap(m.getWidth(),m.getHeight(),Bitmap.Config.RGB_565);for(int x=0;x<m.getWidth();x++)for(int y=0;y<m.getHeight();y++)b.setPixel(x,y,m.get(x,y)?Color.BLACK:Color.WHITE);return b;}catch(Exception e){return Bitmap.createBitmap(size,size,Bitmap.Config.WHITE);}}

    void sharePartner(JSONObject p){Intent s=new Intent(Intent.ACTION_SEND);s.setType("text/plain");s.putExtra(Intent.EXTRA_TEXT,partnerUrl(p));startActivity(Intent.createChooser(s,"Сподели партнерски QR линк"));}
    void finishPartner(JSONObject p){new AlertDialog.Builder(this).setTitle("Заврши исплати").setMessage("Да се завршат исплатите за "+p.optString("name")+" за "+months[monthIndex]+" "+year+"?").setNegativeButton("Откажи",null).setPositiveButton("Заврши",(d,w)->Toast.makeText(this,"Исплатите се означени за завршување.",Toast.LENGTH_SHORT).show()).show();}

    void bottomRemoved(){}

    void operatorPicker(){new AlertDialog.Builder(this).setTitle("Избор на оператор").setSingleChoiceItems(new String[]{"Кирил\nМои партнери и историја","Марјан\nСопствени партнери и историја"},operator.equals("Кирил")?0:1,(d,w)->{operator=w==0?"Кирил":"Марјан";d.dismiss();home();}).setNegativeButton("Откажи",null).show();}
    void monthPicker(){new AlertDialog.Builder(this).setTitle("Месец").setSingleChoiceItems(months,monthIndex,(d,w)->{monthIndex=w;d.dismiss();home();}).show();}
    void yearPicker(){String[] ys={"2026","2027","2028","2029","2030"};new AlertDialog.Builder(this).setTitle("Година").setSingleChoiceItems(ys,Math.max(0,year-2026),(d,w)->{year=2026+w;d.dismiss();home();}).show();}

    void showOperatorQr(String op){new AlertDialog.Builder(this).setTitle("QR за "+op).setView(makeQrView(WORKER+"?operator="+Uri.encode(op))).setPositiveButton("Затвори",null).show();}
    void showPartnerQr(JSONObject p){new AlertDialog.Builder(this).setTitle("QR – "+p.optString("name")).setView(makeQrView(partnerUrl(p))).setPositiveButton("Затвори",null).setNeutralButton("Сподели",(d,w)->sharePartner(p)).show();}
    ImageView makeQrView(String u){ImageView im=new ImageView(this);im.setPadding(dp(14),dp(14),dp(14),dp(14));im.setImageBitmap(makeQr(u,dp(260)));return im;}
}
